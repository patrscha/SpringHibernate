package com.pschaefer.springdemo.Service;

public interface FortuneService {

	public String getFortune();
}
