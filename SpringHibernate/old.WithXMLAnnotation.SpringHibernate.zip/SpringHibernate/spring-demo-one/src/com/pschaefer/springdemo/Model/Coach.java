package com.pschaefer.springdemo.Model;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
}
